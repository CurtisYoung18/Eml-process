# LLM处理结果 - message-1-180.md

## 🤖 AI提取的结构化信息

### 邮件元信息
- **发件人:** Alex Ke <Alex.Ke@nolato.com>
- **收件人:** Kevin Xing <kevin.xing@nolato.com>, Naomi Wang <naomi.wang@nolato.com>, Sally Chen <sally.chen@nolato.com>, Lader Li <Lader.Li@nolato.com>, Tianci Xia <Tianci.Xia@nolato.com>
- **日期:** 2021-12-21 17:11:59
- **主题:** 防水透气膜信息评估-Norgin拜访信息汇总
- **文件名:** message-1-180.eml
- **核心事件:** 项目组汇总防水透气膜开发进展及后续行动项

### 项目主题
本邮件及其往来主要围绕防水透气膜在Audi和Volvo项目中的开发、测试与评估进展。涉及样品提供、测试方法统一、材料工艺、项目时间节点、责任分工和后续行动计划。目标是在春节前完成Norgin材料的开发和验证。

### 关键信息摘要
- 12月底诺臻将提供2~3款膜用于Audi项目，Volvo项目样品暂时无计划，需待Audi项目开发OK后再进行。
- 测试方法需客户、Lovepac、诺臻三方保持一致，诺臻愿意购买一致的测试设备。
- 拒油标准采用AATCC 188标准。
- 诺臻推荐180um无纺布材料（PET+PE），可满足220℃ 10s组装要求。
- 膜材料生产宽度500mm，透气量测试每卷首尾各7个点。
- 样品及测试关键时间节点：
  - 2021/12/24：第一批膜材样品到深圳
  - 2021/12/26：Lovepac完成膜材数据反馈
  - 2022/1/10：第二批膜材样品到深圳（如有需要）
  - 2022/1/12：Lovepac完成Norgin样品膜测试
  - 2022/1/14：Lovepac完成模切件给Nolato做成品
  - 2022/1/17：Nolato收到模切件
  - 2022/1/21：Nolato完成成品阀制作并寄出Lovepac
  - 2022/1/24：Lovepac收到成品阀
  - 2022/1/26：Lovepac完成成品阀测试
- 下一步行动：
  - 核实内部气流量测试治具的气腔形态（负责人：Tianci）
  - 诺臻提供深水膜和无纺布透气膜进行性能测试，双方同步测量水压、透气能力（负责人：Tianci）
  - 6款样品逆向分析报告反馈，推荐类似材料（负责人：Alex）
  - Norgin需回复开发可行性及开发时间（负责人：Alex）

### 详细内容

#### 产品信息
- **型号/类型:** 180um无纺布复合膜
- **规格:** PET+PE组合，可耐220℃ 10s高频热压组装，生产宽度500mm

#### 项目状态更新
- Audi项目膜材开发与测试按计划推进，预计春节前完成材料开发及验证。
- Volvo项目样品开发待Audi项目完成后再启动。
- 测试方法、设备、标准需三方统一，诺臻愿意配合采购一致设备。
- 拒油标准及材料工艺细节已明确，部分细节待进一步验证和数据反馈。

---

*如需详细时间表或责任人分工，可进一步补充。*

---

## 📄 原始邮件内容

# 邮件内容 - message-1-180.eml

## 📧 邮件信息

- **源文件名**: `message-1-180.eml`
- **发件人**: Alex Ke <Alex.Ke@nolato.com>
- **收件人**: Kevin Xing <kevin.xing@nolato.com>, Naomi Wang <naomi.wang@nolato.com>,
	Sally Chen <sally.chen@nolato.com>, Lader Li <Lader.Li@nolato.com>, "Tianci
 Xia" <Tianci.Xia@nolato.com>
- **抄送**: Cindy Lin <cindy.lin@nolato.com>
- **主题**: 防水透气膜信息评估-Norgin拜访信息汇总
- **时间**: 2021-12-21 17:11:59
- **包含的其他邮件**: 9 封

### 📋 包含的源文件列表

- `message-1-183.eml`
- `message-1-186.eml`
- `message-1-206.eml`
- `message-1-207.eml`
- `message-1-208.eml`
- `message-1-209.eml`
- `message-1-211.eml`
- `message-1-212.eml`
- `message-1-213.eml`

## 📄 邮件内容

HI ALL

今天开会汇总，请查收
已确认事项	备注	负责人	1	12月底诺臻提供2~3款膜用于Audi项目，Volvo项目的样品暂时无计划，需要待Audi项目开发OK再进行	volvo项目计划时间？如果拒油不确定，那原膜时间？	Alex	2	测试方法：客户--Lovepac--诺臻 三方保持一致，关键是客
户端的测试方法。诺臻愿意购买与我们保持一致的测试设备	2楼气流设备，G定制？通用的？防水设备G定制，但防水测试有国际标准，差异小，可以双方统一。和nolato确认其设备是否有校准	Sally-Nolato；Lader-Na Sun	3	膜的一致性&稳定
性——制成工艺稳定，选用优质的原材料，膜性能超过最低的要求	　	　	4	拒油的标准——AATCC 188标准	了解拒油物质信息	Lader	5	诺臻推荐180um的无纺布材料，
材质为PET+PE组合，可以满足220℃ 10s的组装要求	通过高频热压方式敷和在原膜上　	6	诺臻的无纺布复合膜采用的热敷贴工艺——无纺布表面凹凸不平，表面层突出部分高温融化，与膜进行热敷贴，融化层压合嵌入到膜的微孔结构中，微观上形成铆钉结构	无纺布不均匀，对透气量影响不确定	　	7	膜材料的生产宽度500mm，透气量测试每卷的首尾各7个点	双方统一测试设备	　	8	诺臻的无纺布复合膜不容易分层，可以满足模切要求	　	　	9	诺臻的膜采用双向拉伸工艺，通过调节拉伸比调整、生产不同的膜	　	　	10诺臻有自己热敷贴设备的专利，没有提供技术方向的专利	Norgin要对技术专利了解Alex	待完成项	备注	负责人	1	核实内部气流量测试治具的气腔形态	　Tianci	2	诺臻提供了一款深水膜、一款无纺布透气膜进行测试膜性能，同步测量提供的样品水压、透气能力	双方数据对比及其目的；为什么提供这两款样品标准是什么Tianci	3	6款样品逆向分析报告反馈，推荐类似材料	　	AlexTHXAlex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Alex Ke
发送时间: 2021年12月14日 16:25
收件人: Kevin Xing <kevin.xing@nolato.com>; Naomi Wang
<naomi.wang@nolato.com>; Sally Chen <sally.chen@nolato.com>; Cindy Lin
<cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>; Tianci Xia
<Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

HI ALL

以下是Pressure Vent项目进度，详情可参考附件
开始时间	持续时间	结束时间	行动	PIC	状态	备注	　	　	　	NDA	AlexClosed	　	2021/12/14	4	2021/12/18	Nolato测试/络派测方式/标准统一	Tianci/Lader/Sally	　	　	2021/12/6	21	2021/12/27	Norgin根据Lovepac的需求试制样品-Audi材料	Norgin	进行中	Alex确认时间/几种	2021/12/16	1	2021/12/17	Norgin拜访:	Lader/Tianci	筹备中	1.测试方法/实验室，差异？如何消除差异？国际标准。是否可提供设备清单2. 产线生产管控，如何保证一致性/稳定性。材料测试项次以及标准
3. 疏油供应商是否可以拜访，拒油材料信息/测试方法/标准
4. 支撑层材料，种类/差异/种类/复合工艺/耐温220°实地看样品
5. 专利状况了解 -Alex
6.  材料开发技术沟通	2021/12/28	2	2021/12/30	Lovepac收到Audi项目样品料
内部1平方厘米膜材测试并反馈Norgin	Tianci/Lader	　	这里指的是Audi项目无疏油需求的膜材	2021/12/31	14	2022/1/14	Norgin根据Lovepac反馈进行调试	Norgin	　	　	2022/1/17	22022/1/19	Lovepac收到调试后的样品料内部1平方厘米膜材测试	Tianci/Lader	　	　	2022/1/19	2	2022/1/21	模切样
品并发给Nolato	Tianci	　	　	2022/1/22	4	2022/1/26	Nolato试制防水透气阀样品并测试David Bao	　	　	2022/1/26	2	2022/1/28	Lovepac测试Nolato防水透气阀
Tianci/Lader	　	　	　	　	　	　	　	　	　	?	　	?	Volvo 样品，拒油是否影响防水透气	Alex	Open需具体Action List以及Schedule	?	　	?	络派测试，Nolato 阀测试	Alex	Open
需具体Action List以及Schedule	　	　	　	　	　	　	　	?	　	?	手提逆向分析样品Tianci/ Lader	Open	需具体Action List以及Schedule	?	　	?	Norgin 回复开
发可行性以及开发时间	Alex	Open	需具体Action List以及ScheduleTHX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Kevin Xing
发送时间: 2021年12月13日 10:00
收件人: Naomi Wang <naomi.wang@nolato.com>; Sally Chen
<sally.chen@nolato.com>; Alex Ke <Alex.Ke@nolato.com>; Cindy Lin
<cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>; Tianci Xia
<Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

Hi All

这周Sally会在深圳，前两天会与Jay梳理Caspain项目的管控和问题。
再与Team梳理Pressure Vent的需求/标准/测试设备/测试方法等，历史和需求我们已经沟通。

后半周Sally/Tianci计划去Norgin了解技术情况，请大家评估是否需要同往。

Best Regards
Kevin Xing
+86 13910312310

发件人: Naomi Wang <naomi.wang@nolato.com>
发送时间: 2021年12月6日 16:58
收件人: Kevin Xing <kevin.xing@nolato.com>; Sally Chen
<sally.chen@nolato.com>; Alex Ke <Alex.Ke@nolato.com>; Cindy Lin
<cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>; Tianci Xia
<Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

大家好，
请见以下schedule，各时间节点以及事项 若有更改请尽快反馈：

Start Date 	Finish Date 	Item 	Status 	2-Dec	2-Dec	Clarify our request
for material development for Audi/Volvo project 	Arranged 	2-Dec	8-DecNDAArranged 	2-Dec	10-Dec	Review and align testing methods and equipment
On-Going 	2-Dec	10-Dec	Prepare sample for Norgin to study & further
development	On-Going 	6-Dec	24-Dec	Norgin first batch samples ETA
Lovepac 	　	24-Dec	26-Dec	Lovepac Internal die-cut& Testing & feedback
to Norgin	　	26-Dec	10-Jan	Norgin Material adjustment & final batch ETA
Lovepac 	　	11-Jan	14-Jan	Lovepac Internal die-cut& testing  	　15-Jan	21-JanNolato finish Pressure vent on 	　	22-Jan	26-Jan	Lovepac finish final
part testing-	　					BR/Naomi

发件人: Kevin Xing <kevin.xing@nolato.com>
发送时间: 2021年12月6日 16:51
收件人: Naomi Wang <naomi.wang@nolato.com>; Sally Chen
<sally.chen@nolato.com>; Alex Ke <Alex.Ke@nolato.com>; Cindy Lin
<cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>; Tianci Xia
<Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

Naomi

这要看膜材的参数情况。

12月24号到深圳，12月26号我们出膜材的数据反馈；合格的话把后续Action提前。

我们测膜材的数据不合格的话26号就可以给出反馈。

因为测试设备不同，这期间还要Norgin尽快提供3种以上不同膜材内部的测试数据与我们测量的数据做对比分析。

Best Regards
Kevin Xing
+86 13910312310

发件人: Naomi Wang <naomi.wang@nolato.com>
发送时间: 2021年12月6日 16:45
收件人: Kevin Xing <kevin.xing@nolato.com>; Sally Chen
<sally.chen@nolato.com>; Alex Ke <Alex.Ke@nolato.com>; Cindy Lin
<cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>; Tianci Xia
<Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

Kevin，

第一批膜材24号到深圳我们测试需要多久，几天可以反馈Norgin调整？
我们也看下1月10号第二批来不来的及，thanks

BR/Naomi

发件人: Kevin Xing <kevin.xing@nolato.com>
发送时间: 2021年12月6日 16:42
收件人: Naomi Wang <naomi.wang@nolato.com>; Sally Chen
<sally.chen@nolato.com>; Alex Ke <Alex.Ke@nolato.com>; Cindy Lin
<cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>; Tianci Xia
<Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

Hi Naomi

我们设定的是Audi项目的膜材样品防水透气量和热压后阀的防水透气量数据评估，目前Volvo项目的需求只能评估到膜材本身防水透气量。

第一批膜材样品最迟是12月24号到深圳，如果有问题第二批膜材样品到深圳设定为1月10号；后续action时间不变。

Best Regards
Kevin Xing
+86 13910312310

发件人: Naomi Wang <naomi.wang@nolato.com>
发送时间: 2021年12月6日 15:36
收件人: Kevin Xing <kevin.xing@nolato.com>; Sally Chen
<sally.chen@nolato.com>; Alex Ke <Alex.Ke@nolato.com>; Cindy Lin
<cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>; Tianci Xia
<Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

另外， Kevin，Sally，

Alex发的时间点是希望看下我们什么时间需要完成什么事情，以在春节前完成Norgin材料的开发以及验证

若有其他意见请随时提出，并组织大家确认各项事宜时间节点，以管控项目进展

Thanks

BR/Naomi

发件人: Naomi Wang
发送时间: 2021年12月6日 15:30
收件人: Kevin Xing <kevin.xing@nolato.com>; Alex Ke <Alex.Ke@nolato.com>;
Cindy Lin <cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>; Tianci Xia
<Tianci.Xia@nolato.com>; Sally Chen <sally.chen@nolato.com>
主题: 回复: 防水透气膜信息评估

Hi Kevin，

我们希望是经过验证后的最终材料时间，目前看时间非常紧张

还请大家关注各方面的沟通、确认与进展，以实现此时间目标

Thanks

BR/Naomi
发件人: Kevin Xing <kevin.xing@nolato.com>
发送时间: 2021年12月6日 15:06
收件人: Alex Ke <Alex.Ke@nolato.com>; Naomi Wang <naomi.wang@nolato.com>;
Cindy Lin <cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>; Tianci Xia
<Tianci.Xia@nolato.com>; Sally Chen <sally.chen@nolato.com>
主题: 回复: 防水透气膜信息评估

Hi Alex

1月10号是Norgin第一批样品材料的到料时间还是经过几轮验证后的最终材料时间？

Best Regards
Kevin Xing
+86 13910312310

发件人: Alex Ke <Alex.Ke@nolato.com>
发送时间: 2021年12月6日 13:57
收件人: Kevin Xing <kevin.xing@nolato.com>; Naomi Wang
<naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>; Lader Li
<Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

HI ALL

附件是圣安最新提供的膜材的TDS，样品已给到天赐

关于测试Norgin样品的时间请参考如下：
1.       1月10日Norgin可以提供样品膜给到Lovepac
2.       1月12日Lovepac完成对Norgin样品膜的测试
3.       1月14日Lovepac完成模切件给到Nolato做成品
4.       1月17日Nolato收到模切件
5.       1月21日Nolato完成成品阀的制作寄出给Lovepac
6.       1月24日Lovepac收到成品阀
7.       1月26日完成对成品阀的测试

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Kevin Xing
发送时间: 2021年12月2日 18:36
收件人: Alex Ke <Alex.Ke@nolato.com>; 姚莹 <yaoying@nor-ally.com>;
david@nor-ally.com; renyongjun@nor-ally.com
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

大家好

请查收附件更新的膜材信息，谢谢。

Best Regards
Kevin Xing
+86 13910312310

发件人: Alex Ke <Alex.Ke@nolato.com>
发送时间: 2021年12月1日 17:54
收件人: 姚莹 <yaoying@nor-ally.com>; david@nor-ally.com;
renyongjun@nor-ally.com
抄送: Naomi Wang <naomi.wang@nolato.com>; Kevin Xing
<kevin.xing@nolato.com>; Cindy Lin <cindy.lin@nolato.com>; Lader Li
<Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

HI Joanna&David&Ren

我这边更新了我们的需求信息以及之前测试Norgin两款膜材的测试数据，请查收

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com
发件人: Alex Ke
发送时间: 2021年12月1日 15:22
收件人: '姚莹' <yaoying@nor-ally.com>; 'david@nor-ally.com；'
<david@nor-ally.com;>; 'renyongjun@nor-ally.com' <renyongjun@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Kevin Xing
<kevin.xing@nolato.com>; Cindy Lin <cindy.lin@nolato.com>; Lader Li
<Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>
主题: 防水透气膜信息评估

HI Joanna & David & Ren

您好，附件是我司需要的对应的膜材数据，还请内部评估。

另外，请贵司提供一下贵司防水透气膜的测试信息，包括具体的仪器设备、测试方法、测试标准。还请今天提供，这样我司有时间内部评估双方差异，以便明天会议做讨论。

您这边确认好明天下午的时间后，请告知我。

THX
Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

---
*处理时间: 2025-09-03 16:23:09*

---
*LLM处理时间: 2025-09-03 16:25:12*
*使用节点: sg*
*API Key: app-OelZ...SG3Frglh*
