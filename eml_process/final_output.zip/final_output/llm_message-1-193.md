# LLM处理结果 - message-1-193.md

## 🤖 AI提取的结构化信息

### 邮件元信息
- **发件人:** Alex Ke <Alex.Ke@nolato.com>
- **收件人:** Kevin Xing <kevin.xing@nolato.com>
- **日期:** 2021-12-08 10:10:45
- **主题:** 回复: RE: [EXTERNAL] 回复: 防水透气膜信息评估
- **文件名:** message-1-193.eml
- **核心事件:** 确认防水透气膜项目的技术要求与样品准备方案

### 项目主题
本邮件链围绕奥迪（Audi）和沃尔沃（Volvo）项目的防水透气膜技术要求、样品准备、测试方法及进度安排进行详细沟通。双方针对最新的技术参数、样品类型、测试标准和交付周期反复确认，以确保后续产品开发和评估顺利进行。

### 关键信息摘要
- 奥迪项目膜材要求：防水，60kpa/30s，透气>1500ml/min/cm²，厚度>0.1mm，疏水，支撑材料耐温220℃/10s，原膜透气需>2500ml/min/cm²。
- 沃尔沃项目膜材要求：防水，10kpa/60min，透气>1500ml/min/cm²，厚度>0.1mm，疏油8级，原膜透气>2500ml/min/cm²，原膜耐水压需20kpa/60min。
- 样品准备：奥迪项目内部定名ND8010，原膜、无复合、无疏油处理；预计出样时间约3周，调整后可缩短至2周。
- 测试方法：要求在7kpa下测试透气量（每平方厘米每分钟），防水测试在60kpa/30s条件下进行。
- 建议样品形式：80mm宽小卷代替A4纸，避免运输和制样损伤。
- 下一步行动：确认技术参数准确性，明确是否需为Audi/Volvo每个项目提供2-3个样品。

### 详细内容

#### 产品信息
- **奥迪项目型号（内部定名）:** ND8010
- **奥迪项目规格:** 防水，60kpa/30s，透气>1500ml/min/cm²，厚度>0.1mm，疏水，耐温220℃/10s，原膜透气>2500ml/min/cm²
- **沃尔沃项目规格:** 防水，10kpa/60min，透气>1500ml/min/cm²，厚度>0.1mm，疏油8级，原膜透气>2500ml/min/cm²，原膜耐水压20kpa/60min

#### 项目状态更新
- 技术参数已多次更新，现需最终确认准确性。
- 奥迪项目样品预计3周内出样，调整后可缩短至2周。
- 沃尔沃项目膜材透气量标准已更新为>1500ml/min/cm²。
- 双方测试方法和样品形式已沟通一致，待确认执行。

---

**备注：** 邮件内容涉及多轮技术参数确认与样品准备安排，所有关键信息均已聚焦于产品规格、测试方法、交付周期和下一步行动。

---

## 📄 原始邮件内容

# 邮件内容 - message-1-193.eml

## 📧 邮件信息

- **源文件名**: `message-1-193.eml`
- **发件人**: Alex Ke <Alex.Ke@nolato.com>
- **收件人**: Kevin Xing <kevin.xing@nolato.com>
- **抄送**: Naomi Wang <naomi.wang@nolato.com>, Cindy Lin <cindy.lin@nolato.com>,
	Tianci Xia <Tianci.Xia@nolato.com>, Sally Chen <sally.chen@nolato.com>,
	"Lader Li" <Lader.Li@nolato.com>
- **主题**: 回复: RE: [EXTERNAL] 回复: 防水透气膜信息评估
- **时间**: 2021-12-08 10:10:45

## 📄 邮件内容

HI Kevin

请帮忙最终确认以下Norgin黄总总结的信息是否准确？

另外，请问针对Audi/Volvo的需求是否要他们每个项目提供2-3个样品？

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: jjhuang
发送时间: 2021年12月8日 1:45
收件人: Lader Li <Lader.Li@nolato.com>; Kevin Xing <kevin.xing@nolato.com>;
Alex Ke <Alex.Ke@nolato.com>; Joanna Yao <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Tianci Xia <Tianci.Xia@nolato.com>; Sally Chen <sally.chen@nolato.com>; 郭卫东
<david@nor-ally.com>; 任永军 <renyongjun@nor-ally.com>; 黄海松
<huanghs@nor-ally.com>
主题: Re: RE: [EXTERNAL] 回复: 防水透气膜信息评估

各位，
综合目前技术信息看，产品的技术要求和我们上次视频会议时发生了比较大的变化，我总结如下，请各位指正。
1，奥迪项目，膜材要求：防水，60kpa/30s，透气>1500ml/min/cm2（12月1日的信息是>500mm/min/cm2)，厚度要求>0.1mm；疏水即可。可以确认该产品要求是有支撑的膜材（原膜厚度一般不会超过0.03mm）。支撑材料耐温要求220度/10s。由于原膜经复合后透气损失大约30-40%之间，因此原膜要求在60kpa/30s条件下透气需要大于2500mm/min/cm2。我们现成产品列表中似乎还没有类似产品，我们会尽快评估并试制产品用于双方检测校准。
2，沃尔沃项目，膜材要求：防水，10kpa/60min，透气>1500ml/min/cm2（12月1日信息是>520ml/min/cm2），厚度要求>0.1mm，疏油8级。可以确认该产品为有支撑的膜材。原膜透气要求也是>2500ml/min/cm2；由于疏油处理的耐水压损失按我们的经验会损失30%，因此该产品原膜耐水压设计需要达到20kpa/60min；该产品数据近似我们现有的NPE6813-P50/NPE6815-P50。
3，如果以上技术数据总结是正确的，那我们就按上述要求试制样品共双方检测。但是我们明白，上述技术要求颇为挑战。我们会尽力而为。
黄炯炯

________________________________
jjhuang

发件人： Lader Li
发送时间： 2021-12-07 16:50
收件人： Kevin Xing; jjhuang; Alex Ke; 姚 莹
抄送： Naomi Wang; Cindy Lin; Tianci Xia; Sally Chen; 郭卫东; 任永军
主题： RE: 回复: [EXTERNAL] 回复: 防水透气膜信息评估
Hi  黄总，
FYI

发件人: jjhuang <jjhuang@nor-ally.com>
发送时间: 2021年12月7日 15:49
收件人: Alex Ke <Alex.Ke@nolato.com>; 姚 莹 <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Kevin
Xing <kevin.xing@nolato.com>; Sally Chen <sally.chen@nolato.com>; 郭卫东
<david@nor-ally.com>; 任永军 <renyongjun@nor-ally.com>
主题: Re: 回复: [EXTERNAL] 回复: 防水透气膜信息评估

Alex,；
今天上午我们专门会议讨论贵方需求和试样问题。有这样几个意见共参考：
1，        发现最新附表中奥迪项目产品的透气量也调整为1500ml/min.cm2，我们暂时无法判断可行性。因为在沃尔沃项目中透气量调整为1500时，耐水压是10kpa/60分钟，差异很大。
---两个项目根据阀体的尺寸和透气量要求核算的膜材透气量均为1500ml/min.cm2；因为Volvo项目今天接到阀体透气量更新所以调整膜材的透气量为＞1500ml/min.cm2；因为是两个不同的项目所以水压测试需求的时间和压力不同，可以根据最新的表格要求开发。
2，        膜材厚度若为0.1mm以上，则肯定是有支撑材料，我们俗称复贴膜。原膜经复合后，透气量会有损失，所以我们要明确技术指标是针对复合后产品，还是原膜。
---模切的厚度我们是基于客户组装的方案提出的，目前Audi项目膜材厚度低于0.1mm组装方面容易变形褶皱；我们表格中给的透气量是对整体膜材本身的要求。
是否需要增加复贴膜需要你们评估， Audi项目客户的组装热压温度是220℃，所以膜材本身需要有耐温220℃/10s的要求。
3，        我们不建议使用随意选取膜材进行测试评价和测试校准，因为不同用途的膜材结构不同，评价方法手段也不同，张冠李戴会失真。所以我们会在双方沟通明白上述标准需求后，设计一款基本可以中的的产品予以测试评估和双方测试校准。那样，即便数据稍有差池，调整会比较快。
--充分理解您那边的顾虑。我们提出这个要求只是想对比下双方测试设备和测试方法的差异。最终肯定是要在客户， Lovepac, 贵司之间达成一致的评估方法和测试方法。
4，        我们不建议采用A4纸作为对照检测膜材，因为A4纸大小平板膜在快递、拆封、实验室制样过程中很容易受损，所以我们会建议使用80mm宽小卷，我们在同一卷前端做测试，贵方收到建材后，适当剔除外层膜后进行检测。
---可以用小卷方式。
5，我们目前聚焦奥迪需要的产品，原膜、无复合、无疏油处理要求，我们内部定名为ND8010，相关技术指标会很快出来。
6，我们明白贵方需求后，出样品时间大约3周，再次调整时间可以控制在2周内。
以上，请指教。
黄炯炯

________________________________
jjhuang

发件人： Alex Ke
发送时间： 2021-12-07 14:33
收件人： yaoying@nor-ally.com
抄送： Naomi Wang; Cindy Lin; Lader Li; Tianci Xia; Kevin Xing; Sally Chen;
david@nor-ally.com; renyongjun@nor-ally.com; jjhuang
主题： 回复: [EXTERNAL] 回复: 防水透气膜信息评估
HI Joanna

如沟通，Volvo项目的透气量有更新，透气膜的透气标准更新为：＞1500ml/min/cm²，详情请见附件

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Alex Ke
发送时间: 2021年12月7日 13:38
收件人: 'yaoying@nor-ally.com' <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Kevin
Xing <kevin.xing@nolato.com>; Sally Chen <sally.chen@nolato.com>;
'david@nor-ally.com' <david@nor-ally.com>; 'renyongjun@nor-ally.com'
<renyongjun@nor-ally.com>; 'jjhuang' <jjhuang@nor-ally.com>
主题: 回复: [EXTERNAL] 回复: 防水透气膜信息评估

HI Joanna

关于Audi以及Volvo的膜材“贴合无纺布”需求不是必要的，只要能够满足透气防水，温度，以及厚度要求就可以。

另，如沟通，上午邮件让贵司提供三款膜材双方先来测试一下，是基于贵司现有的膜材就可以，就是为了确定双方测试的数据差异，和Audi/Volvo的需求无关（Audi/Volvo的需求参考我们之前发的表格信息）。还请近期安排出。

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Alex Ke
发送时间: 2021年12月7日 10:29
收件人: 'yaoying@nor-ally.com' <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Kevin
Xing <kevin.xing@nolato.com>; Sally Chen <sally.chen@nolato.com>;
david@nor-ally.com; renyongjun@nor-ally.com; jjhuang <jjhuang@nor-ally.com>
主题: 回复: [EXTERNAL] 回复: 防水透气膜信息评估

HI Joanna

关于确认测试差异的问题

烦请贵司提供三款不同的膜材，每一款约A4大小，各裁一半，Norgin对A4的一半膜材进行防水透气测试，Lovepac进行另一半A4膜材的防水透气测试。同时请Norgin提供实际测试时的视频。

测试条件：透气量，在7kpa条件下，测试每平方厘米每分钟的透气量；防水测试，在60kpa/30s的条件下进行测试

有任何问题请随时练习

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: yaoying@nor-ally.com
发送时间: 2021年12月7日 10:08
收件人: Alex Ke <Alex.Ke@nolato.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Kevin
Xing <kevin.xing@nolato.com>; Sally Chen <sally.chen@nolato.com>;
david@nor-ally.com; renyongjun@nor-ally.com; jjhuang <jjhuang@nor-ally.com>
主题: [EXTERNAL] 回复: 防水透气膜信息评估

CAUTION: This email originated from outside of the organization. Do not
click links or open attachments unless you recognize the sender and know the
content is safe.

Hello Alex,
邮件收到。
我们稍后开好会后会详细回答这几个问题，并同时抄送我们几位同事在邮件中。

B.Regards
Joanna Yao (姚莹）
Norshine / Norgin
Mobile: 86-13651809834

发件人: Alex Ke <Alex.Ke@nolato.com>
发送时间: 2021年12月7日 9:05
收件人: 姚莹 <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Kevin
Xing <kevin.xing@nolato.com>; Sally Chen <sally.chen@nolato.com>
主题: 回复: 防水透气膜信息评估

HI Joanna

以下信息请帮忙确认：

1.       请问贵司预计提供样品的时间是何时？
2.       如果收到第一批样品测试不达标，需要贵司重新调整，请问这个调整的LT预计多久？
3.       针对Audi项目的样品膜的LT预计多久？针对Volvo项目的样品膜的LT预计多久？

Thx

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Kevin Xing
发送时间: 2021年12月2日 18:36
收件人: Alex Ke <Alex.Ke@nolato.com>; 姚莹 <yaoying@nor-ally.com>;
david@nor-ally.com; renyongjun@nor-ally.com
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

大家好

请查收附件更新的膜材信息，谢谢。

Best Regards
Kevin Xing
+86 13910312310

发件人: Alex Ke <Alex.Ke@nolato.com>
发送时间: 2021年12月1日 17:54
收件人: 姚莹 <yaoying@nor-ally.com>; david@nor-ally.com;
renyongjun@nor-ally.com
抄送: Naomi Wang <naomi.wang@nolato.com>; Kevin Xing
<kevin.xing@nolato.com>; Cindy Lin <cindy.lin@nolato.com>; Lader Li
<Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

HI Joanna&David&Ren

我这边更新了我们的需求信息以及之前测试Norgin两款膜材的测试数据，请查收

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com
发件人: Alex Ke
发送时间: 2021年12月1日 15:22
收件人: '姚莹' <yaoying@nor-ally.com>; 'david@nor-ally.com；'
<david@nor-ally.com;>; 'renyongjun@nor-ally.com' <renyongjun@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Kevin Xing
<kevin.xing@nolato.com>; Cindy Lin <cindy.lin@nolato.com>; Lader Li
<Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>
主题: 防水透气膜信息评估

HI Joanna & David & Ren

您好，附件是我司需要的对应的膜材数据，还请内部评估。

另外，请贵司提供一下贵司防水透气膜的测试信息，包括具体的仪器设备、测试方法、测试标准。还请今天提供，这样我司有时间内部评估双方差异，以便明天会议做讨论。

您这边确认好明天下午的时间后，请告知我。

THX
Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

---
*处理时间: 2025-09-03 16:23:09*

---
*LLM处理时间: 2025-09-03 16:27:33*
*使用节点: sg*
*API Key: app-OelZ...SG3Frglh*
