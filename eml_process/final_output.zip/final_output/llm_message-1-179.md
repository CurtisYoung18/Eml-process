# LLM处理结果 - message-1-179.md

## 🤖 AI提取的结构化信息

### 邮件元信息
- **发件人:** Alex Ke <Alex.Ke@nolato.com>
- **收件人:** Joanna Yao <yaoying@nor-ally.com>
- **日期:** 2021-12-21 17:43:11
- **主题:** 回复: 回复: [EXTERNAL] 回复: 防水透气膜信息评估
- **文件名:** message-1-179.eml
- **核心事件:** 跟进Audi与Volvo项目膜材样品进展及技术问题确认

### 项目主题
本邮件链围绕Lovepac与Norgin/Norshine关于Audi和Volvo项目防水透气膜的开发需求、样品交付、测试方法及技术参数进行多轮沟通。双方就样品交期、膜材技术指标、测试标准、逆向分析及专利情况等进行确认和推进。

### 关键信息摘要
- Audi项目非疏油膜样品预计12月底前提供2-3款，规格为80mm*10m。
- Volvo项目疏油膜样品交期尚未确定，需进一步确认原膜样品完成时间。
- Lovepac已提供6款样品给Norgin，待对方进行逆向分析并反馈可行性及时间安排。
- Audi项目膜材要求：透气量>1500ml/min/cm²，防水IP68(60kpa/30s)，厚度>0.1mm，组装条件220℃/10s。
- Volvo项目膜材要求：透气量>1500ml/min/cm²，防水IP68(10kpa/60min)，厚度>0.1mm，拒油等级8级，组装条件220℃/10s。
- 样品测试如需调整，产品调整周期可控制在2周内。
- 技术/加工专利情况需进一步了解，避免后续开放受限。
- 双方确认测试差异，建议采用80mm宽小卷样品进行对比测试。

### 详细内容

#### 产品信息
- **Audi项目膜材要求**
  - 透气量: >1500ml/min/cm²
  - 防水要求: IP68 (60kpa/30s)
  - 厚度: >0.1mm
  - 组装条件: 220℃/10s
  - 支撑材料：有支撑
- **Volvo项目膜材要求**
  - 透气量: >1500ml/min/cm²
  - 防水要求: IP68 (10kpa/60min)
  - 厚度: >0.1mm
  - 拒油等级: 8级
  - 组装条件: 220℃/10s
  - 支撑材料：有支撑

#### 项目状态更新
- Audi项目样品预计12月底前交付，双方已确认技术参数。
- Volvo项目疏油膜样品交期待确认，原膜样品完成时间需进一步沟通。
- Lovepac已递交6款样品，Norgin将进行逆向分析并反馈开发可行性及时间安排。
- 技术/加工专利需进一步排查，避免影响后续合作。
- 双方确认测试方法和标准差异，建议采用80mm宽小卷样品进行对比测试。

---

## 📄 原始邮件内容

# 邮件内容 - message-1-179.eml

## 📧 邮件信息

- **源文件名**: `message-1-179.eml`
- **发件人**: Alex Ke <Alex.Ke@nolato.com>
- **收件人**: Joanna Yao <yaoying@nor-ally.com>
- **抄送**: renyongjun <renyongjun@nor-ally.com>, wanghan <wanghan@nor-ally.com>,
	david <david@nor-ally.com>, Naomi Wang <naomi.wang@nolato.com>, Kevin Xing
	<kevin.xing@nolato.com>, Sally Chen <sally.chen@nolato.com>, Lader Li
	<Lader.Li@nolato.com>, Tianci Xia <Tianci.Xia@nolato.com>
- **主题**: 回复: 回复: [EXTERNAL] 回复: 防水透气膜信息评估
- **时间**: 2021-12-21 17:43:11
- **包含的其他邮件**: 12 封

### 📋 包含的源文件列表

- `message-1-181.eml`
- `message-1-182.eml`
- `message-1-190.eml`
- `message-1-191.eml`
- `message-1-192.eml`
- `message-1-194.eml`
- `message-1-195.eml`
- `message-1-199.eml`
- `message-1-200.eml`
- `message-1-203.eml`
- `message-1-204.eml`
- `message-1-205.eml`

## 📄 邮件内容

HI Joanna

上次我司同事去拜访贵司以后，有以下几个问题还需要贵司再帮忙确认一下：

1.  贵司反馈12月底提供2~3款膜用于Audi项目。关于Volvo的样品预计什么时候可以给出？如果疏油加工需要确认暂时无法给出，请先确认Volvo的原膜样品预计完成时间。
2.  我司同事这次拜访提供了6款样品，关于相关的逆向分析何时可以给出？是否有类似的现成样品可以推荐？
3.  贵司提供了关于设备的专利，技术/加工方面的专利还需要贵司进一步了解，以避免后续开放受到影响。

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: david
发送时间: 2021年12月16日 8:41
收件人: Alex Ke <Alex.Ke@nolato.com>
抄送: Joanna Yao <yaoying@nor-ally.com>; renyongjun
<renyongjun@nor-ally.com>; wanghan <wanghan@nor-ally.com>
主题: Re: 回复: [EXTERNAL] 回复: 防水透气膜信息评估

Hi Alex:

邮件收悉，回复如下：
1、疏油处理的事务，由市场部负责联络及确定，只需和 Joanna联系即可；
2、12月底，我们会提供2-3个样品，包括原膜和贴合膜；样品规格按双方确定的80mm*10m提供；
3、今天收到贵司样品后，我们会会同相关部门分析、测试，并给与贵司产品开发可行性及时间安排。

感谢对我们的支持！

________________________________
致
礼！

David
david@nor-ally.com

发件人： Alex Ke
发送时间： 2021-12-15 16:21
收件人： yaoying@nor-ally.com; '郭卫东'
抄送： Naomi Wang; Cindy Lin; Tianci Xia; Sally Chen; '黄海松'; Kevin Xing;
Lader Li; 'jjhuang'; '任永军'
主题： 回复: RE: [EXTERNAL] 回复: 防水透气膜信息评估
HI 郭总

除了上封邮件提到事项，是我司技术和质量同事此行拜访贵司要沟通的。还有以下几点，请您这边也帮忙确认：
1.  拒油处理的LT
2.  贵司预计在12月底提供的第一批样品膜，请问是会提供1款还是2-3款？
3.  这次我司同事拜访，会提供一些膜材样品给到贵司做逆向分析，（这是与Audi/Volvo不同的独立的开发项）还请贵司到时候帮忙确认开发的可行性和预计时间等。

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Alex Ke
发送时间: 2021年12月15日 11:31
收件人: 'yaoying@nor-ally.com' <yaoying@nor-ally.com>; '郭卫东'
<david@nor-ally.com>; '任永军' <renyongjun@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Tianci Xia <Tianci.Xia@nolato.com>; Sally Chen <sally.chen@nolato.com>; '黄海松' <huanghs@nor-ally.com>; Kevin Xing <kevin.xing@nolato.com>; Lader Li
<Lader.Li@nolato.com>; 'jjhuang' <jjhuang@nor-ally.com>
主题: 回复: RE: [EXTERNAL] 回复: 防水透气膜信息评估

HI all

如沟通，我司的技术和质量同事预计明天会达到上海拜访贵司，具体时间我司同事会和Joanna这边直接沟通。

关于此次拜访的目的，主要是基于以下几点：
1.了解双方测试方法/设备/标准的差异，如何消除测试差异
2. 了解如何保证材料的一致性/稳定性
3. 了解拒油材料信息/测试方法/标准
4. 了解支撑层材料信息，最好贵司可以提供一些样品现场看一下
5. 了解在防水透气膜材料/加工的专利状况
6. 关于材料开发技术/进度沟通

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: yaoying@nor-ally.com
发送时间: 2021年12月8日 15:27
收件人: Alex Ke <Alex.Ke@nolato.com>; 'jjhuang' <jjhuang@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Tianci Xia <Tianci.Xia@nolato.com>; Sally Chen <sally.chen@nolato.com>; '郭卫东' <david@nor-ally.com>; '任永军' <renyongjun@nor-ally.com>; '黄海松'
<huanghs@nor-ally.com>; Kevin Xing <kevin.xing@nolato.com>; Lader Li
<Lader.Li@nolato.com>
主题: 回复: RE: [EXTERNAL] 回复: 防水透气膜信息评估

Dear Alex,

我与同事们就Kevin确认的更新技术要求重新进行了讨论，包括LT等等信息。

针对Audi 非疏油项目，时间上基本还是可以按昨天黄总给到的回复，初次样品贵司应该可以在12月底前收到（就是距现在3周左右的时间）。
如果测试后有清楚的技术信息反馈及充分的需求及差异讨论，我们的产品调整可以控制在2周内完成。

关于Volvo 疏油样品，交期与Audi不同，稍后回复你相关的信息。

B.Regards
Joanna Yao (姚莹）
Norshine / Norgin
Mobile: 86-13651809834

发件人: Alex Ke <Alex.Ke@nolato.com>
发送时间: 2021年12月8日 11:21
收件人: jjhuang <jjhuang@nor-ally.com>; Joanna Yao <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Tianci Xia <Tianci.Xia@nolato.com>; Sally Chen <sally.chen@nolato.com>; 郭卫东
<david@nor-ally.com>; 任永军 <renyongjun@nor-ally.com>; 黄海松
<huanghs@nor-ally.com>; Kevin Xing <kevin.xing@nolato.com>; Lader Li
<Lader.Li@nolato.com>
主题: 回复: RE: [EXTERNAL] 回复: 防水透气膜信息评估

HI Joanna

目前双方技术信息目前都已经确定，之前贵司反馈出样品时间大约3周，再次调整时间可以控制在2周内，还请帮忙提供一个样品提供计划和交期。特别是针对Audi项目非疏油膜，Volvo项目疏油膜的交期是否不一样，请帮忙确认。

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Kevin Xing
发送时间: 2021年12月8日 10:58
收件人: jjhuang <jjhuang@nor-ally.com>; Lader Li <Lader.Li@nolato.com>; Alex
Ke <Alex.Ke@nolato.com>; Joanna Yao <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Tianci Xia <Tianci.Xia@nolato.com>; Sally Chen <sally.chen@nolato.com>; 郭卫东
<david@nor-ally.com>; 任永军 <renyongjun@nor-ally.com>; 黄海松
<huanghs@nor-ally.com>
主题: 回复: RE: [EXTERNAL] 回复: 防水透气膜信息评估

你好 黄总

关于两个项目的需求我又与客户确认了一遍。

具体请参见附件要求，这里我再给您明确一下，有什么问题随时沟通。

1.  奥迪项目膜材要求:
膜材透气量>1500ml/min/cm2
防水要求IP68(60kpa/30s)
厚度要求>0.1mm
客户组装条件：220℃/10s(热熔到注塑件上)

2.  沃尔沃项目膜材要求：
膜材透气量>1500ml/min/cm2
防水要求IP68(10kpa/60mins)
厚度要求>0.1mm
客户组装条件：220℃/10s(热熔到注塑件上)
拒油等级为8级

按照以上条件客户接受有支撑的膜材，因为你们选择的支撑材料和透气性等问题，需要你们综合评估最终膜材达到以上要求需要匹配的支撑材料。
如果评估一款材料有风险建议每个项目同时开发2-3款来作选择，谢谢。

Best Regards
Kevin Xing
+86 13910312310

发件人: jjhuang <jjhuang@nor-ally.com>
发送时间: 2021年12月8日 1:45
收件人: Lader Li <Lader.Li@nolato.com>; Kevin Xing <kevin.xing@nolato.com>;
Alex Ke <Alex.Ke@nolato.com>; Joanna Yao <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Tianci Xia <Tianci.Xia@nolato.com>; Sally Chen <sally.chen@nolato.com>; 郭卫东
<david@nor-ally.com>; 任永军 <renyongjun@nor-ally.com>; 黄海松
<huanghs@nor-ally.com>
主题: Re: RE: [EXTERNAL] 回复: 防水透气膜信息评估

各位，
综合目前技术信息看，产品的技术要求和我们上次视频会议时发生了比较大的变化，我总结如下，请各位指正。
1，奥迪项目，膜材要求：防水，60kpa/30s，透气>1500ml/min/cm2（12月1日的信息是>500mm/min/cm2)，厚度要求>0.1mm；疏水即可。可以确认该产品要求是有支撑的膜材（原膜厚度一般不会超过0.03mm）。支撑材料耐温要求220度/10s。由于原膜经复合后透气损失大约30-40%之间，因此原膜要求在60kpa/30s条件下透气需要大于2500mm/min/cm2。我们现成产品列表中似乎还没有类似产品，我们会尽快评估并试制产品用于双方检测校准。
2，沃尔沃项目，膜材要求：防水，10kpa/60min，透气>1500ml/min/cm2（12月1日信息是>520ml/min/cm2），厚度要求>0.1mm，疏油8级。可以确认该产品为有支撑的膜材。原膜透气要求也是>2500ml/min/cm2；由于疏油处理的耐水压损失按我们的经验会损失30%，因此该产品原膜耐水压设计需要达到20kpa/60min；该产品数据近似我们现有的NPE6813-P50/NPE6815-P50。
3，如果以上技术数据总结是正确的，那我们就按上述要求试制样品共双方检测。但是我们明白，上述技术要求颇为挑战。我们会尽力而为。
黄炯炯

________________________________
jjhuang

发件人： Lader Li
发送时间： 2021-12-07 16:50
收件人： Kevin Xing; jjhuang; Alex Ke; 姚 莹
抄送： Naomi Wang; Cindy Lin; Tianci Xia; Sally Chen; 郭卫东; 任永军
主题： RE: 回复: [EXTERNAL] 回复: 防水透气膜信息评估
Hi  黄总，
FYI

发件人: jjhuang <jjhuang@nor-ally.com>
发送时间: 2021年12月7日 15:49
收件人: Alex Ke <Alex.Ke@nolato.com>; 姚 莹 <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Kevin
Xing <kevin.xing@nolato.com>; Sally Chen <sally.chen@nolato.com>; 郭卫东
<david@nor-ally.com>; 任永军 <renyongjun@nor-ally.com>
主题: Re: 回复: [EXTERNAL] 回复: 防水透气膜信息评估

Alex,；
今天上午我们专门会议讨论贵方需求和试样问题。有这样几个意见共参考：
1，        发现最新附表中奥迪项目产品的透气量也调整为1500ml/min.cm2，我们暂时无法判断可行性。因为在沃尔沃项目中透气量调整为1500时，耐水压是10kpa/60分钟，差异很大。
---两个项目根据阀体的尺寸和透气量要求核算的膜材透气量均为1500ml/min.cm2；因为Volvo项目今天接到阀体透气量更新所以调整膜材的透气量为＞1500ml/min.cm2；因为是两个不同的项目所以水压测试需求的时间和压力不同，可以根据最新的表格要求开发。
2，        膜材厚度若为0.1mm以上，则肯定是有支撑材料，我们俗称复贴膜。原膜经复合后，透气量会有损失，所以我们要明确技术指标是针对复合后产品，还是原膜。
---模切的厚度我们是基于客户组装的方案提出的，目前Audi项目膜材厚度低于0.1mm组装方面容易变形褶皱；我们表格中给的透气量是对整体膜材本身的要求。
是否需要增加复贴膜需要你们评估， Audi项目客户的组装热压温度是220℃，所以膜材本身需要有耐温220℃/10s的要求。
3，        我们不建议使用随意选取膜材进行测试评价和测试校准，因为不同用途的膜材结构不同，评价方法手段也不同，张冠李戴会失真。所以我们会在双方沟通明白上述标准需求后，设计一款基本可以中的的产品予以测试评估和双方测试校准。那样，即便数据稍有差池，调整会比较快。
--充分理解您那边的顾虑。我们提出这个要求只是想对比下双方测试设备和测试方法的差异。最终肯定是要在客户， Lovepac, 贵司之间达成一致的评估方法和测试方法。
4，        我们不建议采用A4纸作为对照检测膜材，因为A4纸大小平板膜在快递、拆封、实验室制样过程中很容易受损，所以我们会建议使用80mm宽小卷，我们在同一卷前端做测试，贵方收到建材后，适当剔除外层膜后进行检测。
---可以用小卷方式。
5，我们目前聚焦奥迪需要的产品，原膜、无复合、无疏油处理要求，我们内部定名为ND8010，相关技术指标会很快出来。
6，我们明白贵方需求后，出样品时间大约3周，再次调整时间可以控制在2周内。
以上，请指教。
黄炯炯

________________________________
jjhuang

发件人： Alex Ke
发送时间： 2021-12-07 14:33
收件人： yaoying@nor-ally.com
抄送： Naomi Wang; Cindy Lin; Lader Li; Tianci Xia; Kevin Xing; Sally Chen;
david@nor-ally.com; renyongjun@nor-ally.com; jjhuang
主题： 回复: [EXTERNAL] 回复: 防水透气膜信息评估
HI Joanna

如沟通，Volvo项目的透气量有更新，透气膜的透气标准更新为：＞1500ml/min/cm²，详情请见附件

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Alex Ke
发送时间: 2021年12月7日 13:38
收件人: 'yaoying@nor-ally.com' <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Kevin
Xing <kevin.xing@nolato.com>; Sally Chen <sally.chen@nolato.com>;
'david@nor-ally.com' <david@nor-ally.com>; 'renyongjun@nor-ally.com'
<renyongjun@nor-ally.com>; 'jjhuang' <jjhuang@nor-ally.com>
主题: 回复: [EXTERNAL] 回复: 防水透气膜信息评估

HI Joanna

关于Audi以及Volvo的膜材“贴合无纺布”需求不是必要的，只要能够满足透气防水，温度，以及厚度要求就可以。

另，如沟通，上午邮件让贵司提供三款膜材双方先来测试一下，是基于贵司现有的膜材就可以，就是为了确定双方测试的数据差异，和Audi/Volvo的需求无关（Audi/Volvo的需求参考我们之前发的表格信息）。还请近期安排出。

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Alex Ke
发送时间: 2021年12月7日 10:29
收件人: 'yaoying@nor-ally.com' <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Kevin
Xing <kevin.xing@nolato.com>; Sally Chen <sally.chen@nolato.com>;
david@nor-ally.com; renyongjun@nor-ally.com; jjhuang <jjhuang@nor-ally.com>
主题: 回复: [EXTERNAL] 回复: 防水透气膜信息评估

HI Joanna

关于确认测试差异的问题

烦请贵司提供三款不同的膜材，每一款约A4大小，各裁一半，Norgin对A4的一半膜材进行防水透气测试，Lovepac进行另一半A4膜材的防水透气测试。同时请Norgin提供实际测试时的视频。

测试条件：透气量，在7kpa条件下，测试每平方厘米每分钟的透气量；防水测试，在60kpa/30s的条件下进行测试

有任何问题请随时练习

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: yaoying@nor-ally.com
发送时间: 2021年12月7日 10:08
收件人: Alex Ke <Alex.Ke@nolato.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Kevin
Xing <kevin.xing@nolato.com>; Sally Chen <sally.chen@nolato.com>;
david@nor-ally.com; renyongjun@nor-ally.com; jjhuang <jjhuang@nor-ally.com>
主题: [EXTERNAL] 回复: 防水透气膜信息评估

CAUTION: This email originated from outside of the organization. Do not
click links or open attachments unless you recognize the sender and know the
content is safe.

Hello Alex,
邮件收到。
我们稍后开好会后会详细回答这几个问题，并同时抄送我们几位同事在邮件中。

B.Regards
Joanna Yao (姚莹）
Norshine / Norgin
Mobile: 86-13651809834

发件人: Alex Ke <Alex.Ke@nolato.com>
发送时间: 2021年12月7日 9:05
收件人: 姚莹 <yaoying@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Kevin
Xing <kevin.xing@nolato.com>; Sally Chen <sally.chen@nolato.com>
主题: 回复: 防水透气膜信息评估

HI Joanna

以下信息请帮忙确认：

1.       请问贵司预计提供样品的时间是何时？
2.       如果收到第一批样品测试不达标，需要贵司重新调整，请问这个调整的LT预计多久？
3.       针对Audi项目的样品膜的LT预计多久？针对Volvo项目的样品膜的LT预计多久？

Thx

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

发件人: Kevin Xing
发送时间: 2021年12月2日 18:36
收件人: Alex Ke <Alex.Ke@nolato.com>; 姚莹 <yaoying@nor-ally.com>;
david@nor-ally.com; renyongjun@nor-ally.com
抄送: Naomi Wang <naomi.wang@nolato.com>; Cindy Lin <cindy.lin@nolato.com>;
Lader Li <Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

大家好

请查收附件更新的膜材信息，谢谢。

Best Regards
Kevin Xing
+86 13910312310

发件人: Alex Ke <Alex.Ke@nolato.com>
发送时间: 2021年12月1日 17:54
收件人: 姚莹 <yaoying@nor-ally.com>; david@nor-ally.com;
renyongjun@nor-ally.com
抄送: Naomi Wang <naomi.wang@nolato.com>; Kevin Xing
<kevin.xing@nolato.com>; Cindy Lin <cindy.lin@nolato.com>; Lader Li
<Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>
主题: 回复: 防水透气膜信息评估

HI Joanna&David&Ren

我这边更新了我们的需求信息以及之前测试Norgin两款膜材的测试数据，请查收

THX

Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com
发件人: Alex Ke
发送时间: 2021年12月1日 15:22
收件人: '姚莹' <yaoying@nor-ally.com>; 'david@nor-ally.com；'
<david@nor-ally.com;>; 'renyongjun@nor-ally.com' <renyongjun@nor-ally.com>
抄送: Naomi Wang <naomi.wang@nolato.com>; Kevin Xing
<kevin.xing@nolato.com>; Cindy Lin <cindy.lin@nolato.com>; Lader Li
<Lader.Li@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>
主题: 防水透气膜信息评估

HI Joanna & David & Ren

您好，附件是我司需要的对应的膜材数据，还请内部评估。

另外，请贵司提供一下贵司防水透气膜的测试信息，包括具体的仪器设备、测试方法、测试标准。还请今天提供，这样我司有时间内部评估双方差异，以便明天会议做讨论。

您这边确认好明天下午的时间后，请告知我。

THX
Alex Ke

Lövepac Technology(Shenzhen) Co., Ltd
1st. 2nd. Floor, NO.3 Building, NO.1 Lirong Road, Changyi Industrial Area,
Xinshi Community, Dalang Street, Longhua District,
Shenzhen, 518109, P.R.China
Mobile: +86 158-3130-0059
E-mail:Alex.Ke@nolato.com
www.nolato.com

---
*处理时间: 2025-09-03 16:23:09*

---
*LLM处理时间: 2025-09-03 16:24:04*
*使用节点: sg*
*API Key: app-OelZ...SG3Frglh*
