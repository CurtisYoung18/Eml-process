# LLM处理结果 - message-1-188.md

## 🤖 AI提取的结构化信息

### 邮件元信息
- **发件人:** Kevin Xing <kevin.xing@nolato.com>
- **收件人:** Sally Chen <sally.chen@nolato.com>
- **日期:** 2021-12-09 12:47:41
- **主题:** 转发: Norgin and EPTFE
- **文件名:** message-1-188.eml
- **核心事件:** 内部讨论Norgin公司及EPTFE膜业务合作推进计划

### 项目主题
邮件围绕Norgin公司背景、EPTFE膜相关业务能力、与Nolato潜在合作机会及推进计划展开，涉及技术评估、样品测试、标准统一等多项后续行动。

### 关键信息摘要
- Norgin主要产品包括PTFE膜（用于纺织、空气过滤、液体过滤等），有两条EPTFE生产线，单线年产10万平方米仅需10天。
- Norgin创始人Joy Huang具备丰富行业背景，曾任上海3F与Gore合资公司董事长。
- Norgin在军用/消防服装和气体/液体过滤领域有主力业务，消费电子领域拓展不顺，愿意与Nolato合作开拓该市场。
- 近期行动计划：
    - 2周内评估Audi/Volvo膜需求的技术可行性，形成结论。
    - 若可行，2-3个月内与NB/LC/Norgin组建应用小组，制定技术路线图。
    - Lovepac将向Norgin提供膜样品，Norgin开展逆向工程分析。
    - Lovepac与Norgin将组队统一膜测试标准及设备。
- 若上述进展顺利，将安排Jorgen与Joy讨论未来合作。

### 详细内容（如适用）
#### 产品信息
- **主要产品:** PTFE膜（纺织、空气过滤、液体过滤）、EPTFE膜
- **生产能力:** EPTFE生产线2条，单线10万平方米年产仅需10天

#### 项目状态更新
- 当前已启动Audi/Volvo膜需求技术评估，预计2周内有结论。
- 内部已开始梳理质检标准，并与Norgin设备和方法对齐。
- 下一步将推进样品测试、标准统一及后续合作讨论。

---

## 📄 原始邮件内容

# 邮件内容 - message-1-188.eml

## 📧 邮件信息

- **源文件名**: `message-1-188.eml`
- **发件人**: Kevin Xing <kevin.xing@nolato.com>
- **收件人**: Sally Chen <sally.chen@nolato.com>
- **主题**: 转发: Norgin and EPTFE
- **时间**: 2021-12-09 12:47:41

## 📄 邮件内容

Norgin Shanghai Information

Best Regards
Kevin Xing
+86 13910312310

发件人: Dan Wong <Dan.wong@nolato.com>
发送时间: 2021年11月25日 15:08
收件人: Kevin Xing <kevin.xing@nolato.com>; Naomi Wang
<naomi.wang@nolato.com>; Alex Ke <Alex.Ke@nolato.com>; Tianci Xia
<Tianci.Xia@nolato.com>; Cindy Lin <cindy.lin@nolato.com>; Lader Li
<Lader.Li@nolato.com>
主题: RE: Norgin and EPTFE

从第一点开始，Naomi主导拿个方案出来
第四点内部梳理也开始，和Norgin的设备与方法先对一下。

From: Kevin Xing
Sent: 2021年11月25日 13:05
To: Dan Wong <Dan.wong@nolato.com>; Naomi Wang <naomi.wang@nolato.com>; Alex
Ke <Alex.Ke@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>; Cindy Lin
<cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>
Subject: 回复: Norgin and EPTFE

好的Dan，我先了解一下。

Best Regards
Kevin Xing
+86 13910312310

发件人: Dan Wong <Dan.wong@nolato.com>
发送时间: 2021年11月25日 11:41
收件人: Naomi Wang <naomi.wang@nolato.com>; Alex Ke <Alex.Ke@nolato.com>;
Kevin Xing <kevin.xing@nolato.com>; Tianci Xia <Tianci.Xia@nolato.com>;
Cindy Lin <cindy.lin@nolato.com>; Lader Li <Lader.Li@nolato.com>
主题: FW: Norgin and EPTFE

Alex, 故事这么写。

Kevin, 考虑到未来这方面可能是重点，我需要你介入和天赐一起看这块。

请Cindy带队，建立起所有Membrane的质检标准和能力，并与Norgin一起统一构建。

Br/Dan

From: Dan Wong
Sent: 2021年11月25日 11:38
To: Namwei Liew <Namwei.Liew@nolato.com>; Mattias Bengtsson
<mattias.bengtsson@nolato.com>; Naomi Wang <naomi.wang@nolato.com>
Cc: Jörgen Karlsson <jorgen.karlsson@nolato.com>
Subject: Norgin and EPTFE

Norgin Shanghai
China PTFE membrane for textile，PTFE membrane for air filtration，Laminated
membrane，PTFE membrane for liquid filtration Manufacturers, Suppliers and
Factory - Shanghai Norgin Membrane Tech Co.,Ltd.

*  Fluorine materials development started in 1940s, and Dupont released
Teflon late that decade.
*  Fluorine material science study started in Shanghai Organic Fluorine
Materials Research Institute, which established in mid-1970’s
*  Shanghai Organic Fluorine Materials Research Institute had two research
subjects, 1) Tetrafluoroethylene TFE, and 2) Fluor rubber

*  Norgin founder, Mr. Joy Huang, born 1963, local Shanghainese graduated
from East China University of Science and Technology, majored in Polymer
Materials
*  All major technicians in Norgin all from the same major at the same
university above, located in Shanghai.
*  After Mr Joy Huang graduated, in the old Chinese political system, he
become an government administration role in Shanghai Chemical Industry
Bureau in late 1980’s
*  Since 1996, Joy Huang started to be rotated to a big Shanghai stated
owned chemical enterprise as GM
*  In 1999, Joy Huang became the GM of Shanghai Huayi 3F New Material
Co.,Ltd Shanghai Huayi 3F New Materials Co., Ltd. (sh3f.com)

*  Shanghai 3F has been focused on fluoropolymers (PTFE, PVDF, FKM, etc.)
and fluorine fine chemicals etc.
*  Shanghai 3F had a joint venture with Gore US from late 1990s till 2016,
Joy Huang was the chairman of that 3F/Gore company.
*  The reason why Gore teamed up with 3F is: Dupont as Gore’s main PTFE
supplier, didn’t really invest any resources in the development of PTFE
resin, Gore’s volume was nothing in Dupont’s priorities.
*  Shanghai 3F has undertaken the TFE/PTEF development mission for China,
which could cooperate with Gore for those missed early researches which Gore
could not get support from Dupont.
*  Joy Huang thus visited multiple Gore facilities in US, but he never got
into any real Gore’s core material technology, the JV just
did/paid/delivered whatever research Gore requested.

*  Joy Huang left Shanghai 3F and founded Norgin 2005, he was fed up with
the government and stated-owned enterprise system.
*  Except Norgin Shanghai, Joy Huang has another factory in Suzhou, focusing
on the PTFE wear resistance addictive for the polymer resin/compound
industry
*  According to Joy Huang, all Sabic Asian factories are using his wear
resistance addictive, nearly single source
*  I have witnessed two EPTFE production lines yesterday in Norgin, 30
meters long expand to 2m width, one is running production.
*  Joy Huang says if annual consumption will be 100,000 sqm from us, it will
take only 10 days production.

*  There are dozens of EPTFE lines in China, as PTFE compound requests some
rare formula ingredient materials, supplied by very few payers in the game
and Joy knows them all.
*  Joy never heard SINAN, he is highly suspicious they are manufacturing
EPTFE by above sources, but he knows Voir, the vent manufacturer.
*  Norgin has two main business: Fabric for special clothing in Europe
(military/fireman etc), and Gas/Liquid filtering.
*  Norgin tried to enter consumer electronics business since 2015 but not
successful at all, Norgin would like continue to do so if we could help, to
balance his product mix and capacity.
*  The reasons Joy believe for such an unsuccessful development in Consumer
Electronics are:
*  Converters does not really know membrane
*  Gaps between Norgin / Converters / Customers, very difficult to
understand the application failure root causes, testing criteria are
different, each parties are on different page for true application needs
*  Norgin as a small player, cannot really get into leading customer vendor
pool, lack of channels and requested a very long lead time.

That’s all what we can offer to Norgin, where Joy became very positive to
our ideas.

Actions
1.          Further reviews on current Audi/Volvo membrane requests (Norgin
believe it is feasible technically), hopefully form technical conclusions
within 2 weeks
2.         If positive, establish an application panel among NB/LC/Norgin,
scan existing main application and work out technical roadmap by 2-3 months
3.         Lovepac will supply Norgin some membrane samples, Norgin will do
reverse engineering study, in parallel
4.         Lovepac and Norgin will form a team to align and standardize all
membrane testing criteria and equipment

If all above get progressed in a desirable way, I will bring Jorgen and Joy
together for a future cooperation setup discussion.

Br/Dan

---
*处理时间: 2025-09-03 16:23:09*

---
*LLM处理时间: 2025-09-03 16:27:47*
*使用节点: sg*
*API Key: app-OelZ...SG3Frglh*
