# LLM处理结果 - message-1-178.md

## 🤖 AI提取的结构化信息

### 邮件元信息
- **发件人:** Tianci Xia <Tianci.Xia@nolato.com>
- **收件人:** Alex Ke <Alex.Ke@nolato.com>, Lader Li <Lader.Li@nolato.com>
- **日期:** 2022-03-08 15:34:07
- **主题:** Volvo 防水透气膜测试结果
- **文件名:** message-1-178.eml
- **核心事件:** 提供Volvo项目防水透气膜ND8011-P50B的测试结果

### 项目主题
诺臻为Volvo项目提供ND8011-P50B型号防水透气膜的测试数据，未进行拒油测试，仅进行防水透气性能测试并反馈结果。

### 关键信息摘要
- 测试产品: ND8011-P50B
- 批次号: 220120KC02-2
- 拒油测试: 未进行
- 防水测试: 合格（水压10Kpa/60min，全部样品OK）
- 气流测试标准: ≥1500 cm³/(min*cm²)
- 实测气流值: 3700 cm³/(min*cm²)
- 各样品气流@70Mbar：2676、2919、2795、2808、2487、2656、2878、2552、2677、2619、2668、2839、2624、2530、2726、2496、2385、2916、2482、2785

### 详细内容
#### 产品信息
- **型号:** ND8011-P50B
- **批次:** 220120KC02-2

#### 项目状态更新
- 当前测试仅完成防水透气性能，所有样品均合格，未进行拒油测试。

---

## 📄 原始邮件内容

# 邮件内容 - message-1-178.eml

## 📧 邮件信息

- **源文件名**: `message-1-178.eml`
- **发件人**: Tianci Xia <Tianci.Xia@nolato.com>
- **收件人**: Alex Ke <Alex.Ke@nolato.com>, Lader Li <Lader.Li@nolato.com>
- **抄送**: Kevin Xing <kevin.xing@nolato.com>, Naomi Wang <naomi.wang@nolato.com>,
	Sally Chen <sally.chen@nolato.com>
- **主题**: Volvo 防水透气膜测试结果
- **时间**: 2022-03-08 15:34:07

## 📄 邮件内容

Hi Alex:

下面的为诺臻为Volvo项目提供的拒油防水透气膜测试结果（没有进行拒油测试），烦请查收，谢谢！
ND8011-P50B样品测试数据	型号	批次	合格标准	来料测试数据	测试条件	1	23	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	ND8011-P50B	220120KC02-2	/	合格	水压10Kpa/60min	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	OK	≥1500cm³/(min*cm²）	3700cm³/(min*cm²）	气流@70Mbar	2676	2919	2795	2808	2487	2656	28782552	2677	2619	2668	2839	2624	2530	2726	2496	2385	2916	2482	2785以上_ _
Tianci Xia
Technical Engineer

Lövepac technology(Shenzhen) Co., Ltd
1st. 2nd. Floor,NO.3 building,
NO.1 Lirong Road, Changyi Industrial Area,Xinshi Community
Dalang Street,Longhua District, Shenzhen
Post code: 518109
Mobile:  +86  18819513240
E-mail: Tianci.Xia@nolato.com
www.nolato.com
络派科技（深圳）有限公司
深圳市龙华新区大浪街道丽荣路1号国乐科技园3栋2层
络派科技（深圳）有限公司
深圳市龙华新区大浪街道丽荣路1号国乐科技园3栋2层

---
*处理时间: 2025-09-03 16:23:09*

---
*LLM处理时间: 2025-09-03 16:24:19*
*使用节点: sg*
*API Key: app-OelZ...SG3Frglh*
